"""Predictive link model (our extension of the paper's Gaussian link-reliability idea).

Paper: D_l = T_R / delta_v, with delta_v ~ Normal(mu, sigma), reliability = integral of g(T).
Ours:  predict the pair distance tau seconds ahead with constant relative velocity,
       d_hat(tau) = |dp + dv * tau|.  Because distance is convex in time, a link that is
       inside range now and at tau is inside range for the whole interval, so
           S_ij(tau) = P(link survives tau) = Phi((R - d_hat) / sigma_p)
       where sigma_p is the std of the prediction error, estimated online from the
       errors the predictor actually made tau seconds ago (sigma_p ~ sigma_dv * tau).
Also provides the exact kinematic lifetime L_ij (time until |dp + dv t| = R).
"""
import numpy as np
from scipy.special import ndtr


def precompute(pos, vel, cfg, dt):
    R = cfg["radio_range_m"]
    tau = cfg["horizon_tau_s"]
    k = max(1, int(round(tau / dt)))
    Lmax = cfg["l_max_s"]
    T, N, _ = pos.shape
    D = np.empty((T, N, N))
    Dhat = np.empty((T, N, N))
    L = np.empty((T, N, N))
    for t in range(T):
        dp = pos[t][None, :, :] - pos[t][:, None, :]
        dv = vel[t][None, :, :] - vel[t][:, None, :]
        D[t] = np.linalg.norm(dp, axis=2)
        Dhat[t] = np.linalg.norm(dp + dv * tau, axis=2)
        a = (dv ** 2).sum(2)
        b = 2 * (dp * dv).sum(2)
        c = (dp ** 2).sum(2) - R * R
        Lt = np.full((N, N), Lmax)
        mov = a > 1e-9
        disc = b * b - 4 * a * c
        ok = mov & (disc >= 0)
        root = np.zeros_like(a)
        root[ok] = (-b[ok] + np.sqrt(disc[ok])) / (2 * a[ok])
        Lt[ok] = np.clip(root[ok], 0, Lmax)
        Lt[c > 0] = 0.0
        L[t] = Lt
    eye = np.eye(N, dtype=bool)

    # online estimate of prediction-error std (causal: uses only errors already observed)
    ss = np.zeros(T)
    cnt = np.zeros(T)
    for t in range(k, T):
        m = (D[t - k] <= R) & ~eye
        e = D[t] - Dhat[t - k]
        ss[t] = (e[m] ** 2).sum()
        cnt[t] = m.sum()
    W = max(1, int(round(cfg["sigma_window_s"] / dt)))
    sigma = np.full(T, float(cfg["sigma_init_m"]))
    for t in range(T):
        lo = max(0, t - W + 1)
        c = cnt[lo:t + 1].sum()
        if c >= 30:
            sigma[t] = max(cfg["sigma_floor_m"], np.sqrt(ss[lo:t + 1].sum() / c))

    S = ndtr((R - Dhat) / sigma[:, None, None])
    S[(D > R) | eye[None]] = 0.0
    return {"D": D, "S": S, "L": L, "sigma": sigma, "k": k, "N": N, "T": T}


def prediction_quality(pre, cfg):
    """How good are the survival predictions? Compare S_ij(tau) made at time t
    with whether the link really stayed in range for the whole next tau seconds."""
    R = cfg["radio_range_m"]
    D, S, L, k = pre["D"], pre["S"], pre["L"], pre["k"]
    T, N = pre["T"], pre["N"]
    eye = np.eye(N, dtype=bool)
    P, Y, Lk = [], [], []
    for t in range(T - k):
        m = (D[t] <= R) & ~eye
        if not m.any():
            continue
        alive = (D[t:t + k + 1] <= R).all(axis=0)
        P.append(S[t][m])
        Y.append(alive[m].astype(float))
        Lk.append((L[t][m] >= cfg["horizon_tau_s"]).astype(float))
    if not P:
        return {}
    P, Y, Lk = np.concatenate(P), np.concatenate(Y), np.concatenate(Lk)
    base = Y.mean()
    return {
        "pairs_evaluated": int(len(Y)),
        "survival_rate": float(base),
        "brier_prob_model": float(np.mean((P - Y) ** 2)),
        "brier_constant_rate": float(np.mean((base - Y) ** 2)),
        "acc_prob_model@0.5": float(np.mean((P >= 0.5) == (Y == 1))),
        "acc_kinematic@tau": float(np.mean(Lk == Y)),
    }
