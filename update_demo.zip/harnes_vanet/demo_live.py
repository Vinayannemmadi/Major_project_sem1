#!/usr/bin/env python3
"""LIVE DEMO: SUMO traffic + HARNES clustering + our cost-aware clustering, side by side.

What happens
  1. Builds the SUMO scenario (grid road network + N cars with random routes), the same
     scenario generator as the batch experiments (scripts/gen_sumo_traces.py).
  2. Starts SUMO with its GUI and controls it step by step through TraCI
     (SUMO's "Traffic Control Interface": Python asks SUMO for every car's position,
     speed and heading each second).
  3. Every second BOTH clustering models run on exactly the same cars:
        HARNES  = betweenness-centrality cluster heads, re-clustering every 10 s
        OURS    = predictive, cost-aware cluster maintenance
     Cars in SUMO are coloured by the clusters of ONE model (--show):
        cluster head = red marker on the car, members = their cluster's colour,
        unaffiliated = grey.
  4. A live chart shows both models' cumulative control messages, CH elections,
     forced re-joins and CPU time while the traffic runs.
  5. At the end: a comparison table, saved to results/demo/.

Run (from the project folder, venv active):
  python demo_live.py                         # 50 cars, colours show OUR model
  python demo_live.py --show harnes           # colours show HARNES instead
  python demo_live.py --nodes 80 --delay 50   # more cars, faster
  python demo_live.py --nogui --no-plot       # headless check (no windows)

Inputs to SUMO : results/demo/_scenario/grid.net.xml   (road network, from netgenerate)
                 results/demo/_scenario/routes.rou.xml (cars and routes)
                 results/demo/_scenario/demo.sumocfg   (SUMO configuration; you can also
                                                         open it yourself: sumo-gui -c ...)
Outputs        : results/demo/summary.md, timeseries.csv, live_chart.png
"""
import argparse
import os
import shutil
import sys
import time

import numpy as np
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "src"))
sys.path.insert(0, os.path.join(HERE, "scripts"))
if os.environ.get("SUMO_HOME"):
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))

from vanet.link_model import OnlineLinkModel   # noqa: E402
from vanet.policies import Ctx, make_policy    # noqa: E402
from vanet.simulator import summarize          # noqa: E402

MODELS = {"harnes": "periodic", "ours": "costaware"}
NAMES = {"harnes": "HARNES (periodic 10 s)", "ours": "Ours (cost-aware)"}
PALETTE = [(31, 119, 180), (44, 160, 44), (255, 127, 14), (148, 103, 189), (23, 190, 207),
           (188, 189, 34), (227, 119, 194), (140, 86, 75), (0, 128, 128), (128, 128, 0),
           (70, 130, 255), (255, 200, 0)]
GREY, RED = (150, 150, 150, 255), (255, 0, 0, 255)


# ----------------------------------------------------------------- scenario
def build_scenario(cfg, n, seed, out_dir, end_s):
    """Writes net, routes and a .sumocfg. Same generator and seeds as the batch traces,
    so the demo with --nodes N --seed S drives the same traffic as traces/sumo/N{N}_s{S}."""
    import sumolib
    from gen_sumo_traces import make_net, make_routes
    os.makedirs(out_dir, exist_ok=True)
    netfile = make_net(cfg, out_dir)
    rou = os.path.join(out_dir, "routes.rou.xml")
    make_routes(sumolib.net.readNet(netfile), n, 1000 * n + seed, rou)
    sumocfg = os.path.join(out_dir, "demo.sumocfg")
    with open(sumocfg, "w") as f:
        f.write(f"""<configuration>
    <input>
        <net-file value="{os.path.basename(netfile)}"/>
        <route-files value="{os.path.basename(rou)}"/>
    </input>
    <time>
        <begin value="0"/>
        <end value="{end_s}"/>
        <step-length value="{cfg['step_s']}"/>
    </time>
    <processing>
        <time-to-teleport value="-1"/>
    </processing>
    <random_number>
        <seed value="{seed}"/>
    </random_number>
    <report>
        <no-step-log value="true"/>
        <no-warnings value="true"/>
    </report>
</configuration>
""")
    return sumocfg


# ----------------------------------------------------------------- live chart
class LiveChart:
    def __init__(self, enabled):
        self.ok = False
        if not enabled:
            return
        import matplotlib
        for backend in ("TkAgg", "QtAgg", "Qt5Agg", "GTK3Agg"):
            try:
                matplotlib.use(backend, force=True)
                import matplotlib.pyplot as plt
                plt.figure().clf()
                plt.close("all")
                self.ok = True
                break
            except Exception:
                continue
        if not self.ok:
            print("NOTE: no interactive plot backend found (install python3-tk); "
                  "live numbers are printed in the terminal and the chart is saved at the end.")
            return
        import matplotlib.pyplot as plt
        self.plt = plt
        plt.ion()
        self.fig, axes = plt.subplots(2, 2, figsize=(11, 7))
        self.axes = axes.ravel()
        self.fig.canvas.manager.set_window_title("HARNES vs Ours: live comparison")
        self.lines = {}
        titles = ["Control messages (cumulative)", "CH elections (cumulative)",
                  "Forced re-joins (cumulative)", "Maintenance CPU (ms, cumulative)"]
        for ax, ttl in zip(self.axes, titles):
            ax.set_title(ttl, fontsize=10)
            ax.set_xlabel("time (s)")
            ax.grid(alpha=.3)
            for key, col in (("harnes", "#777777"), ("ours", "#2b6cb0")):
                self.lines[(ttl, key)], = ax.plot([], [], color=col, lw=2, label=NAMES[key])
        self.titles = titles
        self.axes[0].legend(fontsize=8, loc="upper left")
        self.fig.tight_layout()

    def update(self, ts):
        if not self.ok:
            return
        cols = ["msgs", "elections", "rejoins", "cpu_ms"]
        for ttl, c in zip(self.titles, cols):
            for key in ("harnes", "ours"):
                self.lines[(ttl, key)].set_data(ts["t"], ts[f"{key}_{c}"])
        for ax in self.axes:
            ax.relim()
            ax.autoscale_view()
        self.fig.canvas.draw_idle()
        self.plt.pause(0.001)


def save_chart(ts, path):
    import matplotlib
    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    for ax, (c, ttl) in zip(axes.ravel(), [("msgs", "Control messages (cumulative)"),
                                           ("elections", "CH elections (cumulative)"),
                                           ("rejoins", "Forced re-joins (cumulative)"),
                                           ("cpu_ms", "Maintenance CPU (ms, cumulative)")]):
        for key, col in (("harnes", "#777777"), ("ours", "#2b6cb0")):
            ax.plot(ts["t"], ts[f"{key}_{c}"], color=col, lw=2, label=NAMES[key])
        ax.set_title(ttl, fontsize=10)
        ax.set_xlabel("time (s)")
        ax.grid(alpha=.3)
    axes[0, 0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)


# ----------------------------------------------------------------- SUMO view
class SumoView:
    """Colours cars by cluster and puts a red marker on each cluster head."""

    def __init__(self, traci, ids, gui):
        self.traci, self.ids, self.gui = traci, ids, gui
        self.markers = set()
        self.poi_ok = gui

    def paint(self, head):
        tr = self.traci
        idx = {}
        for i, vid in enumerate(self.ids):
            h = head[i]
            if h < 0:
                col = GREY
            else:
                if h not in idx:
                    idx[h] = PALETTE[h % len(PALETTE)] + (255,)
                col = RED if h == i else idx[h]
            tr.vehicle.setColor(vid, col)
        if not self.poi_ok:
            return
        try:
            chs = {i for i in range(len(self.ids)) if head[i] == i}
            want = {f"CH_{self.ids[i]}": i for i in chs}
            for pid in self.markers - set(want):
                tr.poi.remove(pid)
            for pid, i in want.items():
                x, y = tr.vehicle.getPosition(self.ids[i])
                if pid in self.markers:
                    tr.poi.setPosition(pid, x, y)
                else:
                    tr.poi.add(pid, x, y, RED, layer=100, width=14, height=14)
            self.markers = set(want)
        except Exception as e:      # markers are cosmetic; never stop the demo for them
            print("NOTE: CH markers disabled:", e)
            self.poi_ok = False


# ----------------------------------------------------------------- main loop
def run(args, traci=None, sumocfg=None):
    cfg = yaml.safe_load(open(os.path.join(HERE, "config.yaml")))
    dt, R, theta = cfg["step_s"], cfg["radio_range_m"], cfg["join_threshold"]
    warm = args.warmup if args.warmup is not None else cfg["warmup_s"]
    dur = args.duration if args.duration is not None else cfg["duration_s"]
    out = os.path.join(HERE, "results", args.tag)
    os.makedirs(out, exist_ok=True)

    if traci is None:
        import traci
    if sumocfg is None:
        binary = "sumo" if args.nogui else "sumo-gui"
        if not shutil.which(binary):
            sys.exit(f"'{binary}' not found. Install SUMO: sudo apt install sumo sumo-tools sumo-doc")
        sumocfg = build_scenario(cfg, args.nodes, args.seed, os.path.join(out, "_scenario"),
                                 warm + dur + 2 * dt)
        cmd = [binary, "-c", sumocfg]
        if not args.nogui:
            cmd += ["--start", "--quit-on-end", "--delay", str(args.delay)]
        traci.start(cmd)
    gui = not args.nogui

    # ---- warm-up: let the cars spread over the map
    print(f"warm-up {warm:.0f} s ...", flush=True)
    while traci.simulation.getTime() < warm - 1e-9:
        traci.simulationStep()
    ids = sorted(traci.vehicle.getIDList())
    N = len(ids)
    if N != args.nodes:
        print(f"WARNING: wanted {args.nodes} cars, {N} are in the network")
    if gui:
        try:
            xmin_ymin, xmax_ymax = traci.simulation.getNetBoundary()
            traci.gui.setBoundary("View #0", xmin_ymin[0] - 50, xmin_ymin[1] - 50,
                                  xmax_ymax[0] + 50, xmax_ymax[1] + 50)
        except Exception:
            pass

    link = OnlineLinkModel(N, cfg, dt)
    pols = {k: make_policy(v, N, cfg, dt) for k, v in MODELS.items()}
    view = SumoView(traci, ids, gui)
    chart = LiveChart(not args.no_plot)
    ts = {"t": []}
    for k in MODELS:
        for c in ("msgs", "elections", "rejoins", "cpu_ms", "clusters"):
            ts[f"{k}_{c}"] = []

    def read_state():
        pos = np.zeros((N, 2))
        vel = np.zeros((N, 2))
        for i, vid in enumerate(ids):
            pos[i] = traci.vehicle.getPosition(vid)
            a = np.radians(traci.vehicle.getAngle(vid))
            s = traci.vehicle.getSpeed(vid)
            vel[i] = (s * np.sin(a), s * np.cos(a))
        return pos, vel

    steps = int(round(dur / dt)) + 1
    print(f"running {dur:.0f} s with {N} cars; SUMO colours show: {NAMES[args.show]}", flush=True)
    t_wall = {k: 0.0 for k in MODELS}
    for t in range(steps):
        if t > 0:
            traci.simulationStep()
            if len(traci.vehicle.getIDList()) < N:
                print("A car left the network; stopping early.")
                steps = t
                break
        pos, vel = read_state()
        D, S, L = link.update(pos, vel)
        ctx = Ctx(t, D, S, L, R, theta)
        for k, p in pols.items():
            t0 = time.perf_counter()
            if t == 0:
                p.initial(ctx)
            else:
                p.timed_step(ctx)
            t_wall[k] += time.perf_counter() - t0
        view.paint(pols[args.show].head)

        ts["t"].append(t * dt)
        for k, p in pols.items():
            ts[f"{k}_msgs"].append(p.m["control_msgs"])
            ts[f"{k}_elections"].append(p.m["ch_elections"])
            ts[f"{k}_rejoins"].append(p.m["forced_rejoins"])
            ts[f"{k}_cpu_ms"].append(1000 * p.m["cpu_s"])
            ts[f"{k}_clusters"].append(len(p.chs()))
        if t % 5 == 0:
            chart.update(ts)
        if t % 10 == 0:
            print(f"t={t * dt:5.0f}s | " + " | ".join(
                f"{NAMES[k]}: msgs={p.m['control_msgs']:5d} CH-elections={p.m['ch_elections']:4d} "
                f"clusters={len(p.chs()):2d}" for k, p in pols.items()), flush=True)
    traci.close()

    # ---- results
    for p in pols.values():
        p.finish(steps - 1)
    res = {k: summarize(p, MODELS[k], N, steps, dt, t_wall[k]) for k, p in pols.items()}
    rows = [("CH elections / min", "ch_elections_per_min", True),
            ("Average CH tenure (s)", "avg_ch_tenure_s", False),
            ("Control messages / min", "control_msgs_per_min", True),
            ("Control share of all messages", "overhead_ratio", True),
            ("Forced re-joins / min", "forced_rejoins_per_min", True),
            ("Maintenance CPU (ms / step)", "cpu_ms_per_step", True),
            ("Unaffiliated vehicles (fraction)", "unaffiliated_frac", True),
            ("Average cluster size", "avg_cluster_size", None)]
    lines = [f"# Live demo: {N} cars, seed {args.seed}, {(steps - 1) * dt:.0f} s measured\n",
             f"| Metric | {NAMES['harnes']} | {NAMES['ours']} | Change |", "|---|---|---|---|"]
    for name, key, lower in rows:
        a, b = res["harnes"][key], res["ours"][key]
        chg = f"{100 * (b - a) / a:+.1f}%" if a else "n/a"
        mark = "" if lower is None else (" (better)" if (b < a) == lower else " (worse)")
        lines.append(f"| {name} | {a:.3f} | {b:.3f} | {chg}{mark} |")
    lines.append("\nOne run (one seed): for the reported results use run_experiments.py "
                 "(10 seeds, confidence intervals).")
    txt = "\n".join(lines)
    print("\n" + txt)
    open(os.path.join(out, "summary.md"), "w").write(txt + "\n")
    import csv
    with open(os.path.join(out, "timeseries.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(list(ts))
        w.writerows(zip(*ts.values()))
    save_chart(ts, os.path.join(out, "live_chart.png"))
    print("saved:", os.path.join(out, "summary.md"), "| timeseries.csv | live_chart.png")
    if chart.ok and not args.no_wait:
        print("Close the chart window to exit.")
        chart.plt.ioff()
        chart.plt.show()
    return res


def parse(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--nodes", type=int, default=50, help="number of cars")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--show", choices=["ours", "harnes"], default="ours",
                    help="whose clusters colour the cars in SUMO")
    ap.add_argument("--delay", type=int, default=100, help="SUMO-GUI delay per step (ms)")
    ap.add_argument("--warmup", type=float, default=None)
    ap.add_argument("--duration", type=float, default=None)
    ap.add_argument("--nogui", action="store_true", help="run SUMO without its window")
    ap.add_argument("--no-plot", action="store_true", help="no live chart window")
    ap.add_argument("--no-wait", action="store_true", help="do not keep the chart open at the end")
    ap.add_argument("--tag", default="demo")
    return ap.parse_args(argv)


if __name__ == "__main__":
    run(parse())
